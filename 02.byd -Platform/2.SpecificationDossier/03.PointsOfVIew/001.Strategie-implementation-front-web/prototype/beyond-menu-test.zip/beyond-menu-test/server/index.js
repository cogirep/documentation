const express = require('express')
const app = express()
const port = process.env.PORT || 5000

app.use(function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*')
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept')
  next()
})

app.get('/', (req, res) => res.send('Beyo~~~~~~~~~~~~~nnnnnd!'))

app.get('/navigation', (req, res) => res.json([{
  'title': 'APP 1',
  'location': 'http://localhost:5001'
}, {
  'title': 'APP 2',
  'location': 'http://localhost:5002'
}, {
  'title': 'APP 3',
  'location': 'http://localhost:5003'
}

]))

app.listen(port, () => console.log(`Navigation Server listening on port ${port}!`))
